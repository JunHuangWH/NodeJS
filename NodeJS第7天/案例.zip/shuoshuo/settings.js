/**
 * Created by Danny on 2015/9/25 11:31.
 */
module.exports = {
    "dburl" : "mongodb://localhost:27017/shuoshuo"
}